import React, { useState } from "react";
import "./styles.css";
import SpinningWheel from "./SpinningWheel";

export default function App() {
  return (
    <>
      <SpinningWheel />
    </>
  );
}
