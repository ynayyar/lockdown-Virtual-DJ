import React from "react";

export default function SpinningWheel() {
  spinWheel = () => {
    const x = 1024; //min value
    const y = 9999; //max value

    const deg = Math.floor(Math.random() * (x - y) + y);
  };

  return (
    <div>
      <div className="mainbox">
        <div className="box">
          <div className="box1">
            <span className="span1">
              <p> Funny jokes </p> <b>50</b>
            </span>
            <span className="span2">
              <p>Shayari</p> <b>150</b>
            </span>
            <span className="span3">
              <b>250</b>
            </span>
            <span className="span4">
              <b>350</b>
            </span>
          </div>
          <div className="box2">
            <span className="span1">
              <b>10</b>
            </span>
            <span className="span2">
              <b>110</b>
            </span>
            <span className="span3">
              <b>210</b>
            </span>
            <span className="span4">
              <b>310</b>
            </span>
          </div>
        </div>
        <button className="spin" onClick={this.spinWheel}>
          SPIN
        </button>
      </div>
    </div>
  );
}
